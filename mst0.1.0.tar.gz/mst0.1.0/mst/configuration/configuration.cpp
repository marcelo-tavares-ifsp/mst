#include "configuration.h"

Q_LOGGING_CATEGORY(configuration_category, "mst.configuration")

Configuration::Configuration()
{

}
